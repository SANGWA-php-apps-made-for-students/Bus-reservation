
--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
`account_id`     int(11) NOT NULL AUTO_INCREMENT 
, `account_category`     int(11)   
,`date_created`     Date 
, `profile`     int(11)   
,`username`     VARCHAR(60) 
,`password`     VARCHAR(60) 
,`is_online`     VARCHAR(60) 

,PRIMARY KEY (`account_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `account_category`
--

CREATE TABLE IF NOT EXISTS `account_category` (
`account_category_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`account_category_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `profile`
--

CREATE TABLE IF NOT EXISTS `profile` (
`profile_id`     int(11) NOT NULL AUTO_INCREMENT 
,`dob`     Date 
,`name`     VARCHAR(60) 
,`last_name`     VARCHAR(60) 
,`gender`     VARCHAR(60) 
,`telephone_number`     VARCHAR(60) 
,`email`     VARCHAR(60) 
,`residence`     VARCHAR(60) 
, `image`     int(11)   

,PRIMARY KEY (`profile_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `bus`
--

CREATE TABLE IF NOT EXISTS `bus` (
`bus_id`     int(11) NOT NULL AUTO_INCREMENT 
, `no_seats`     int(11)   
,`plate_number`     VARCHAR(60) 
, `driver`     int(11)   

,PRIMARY KEY (`bus_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `line`
--

CREATE TABLE IF NOT EXISTS `line` (
`line_id`     int(11) NOT NULL AUTO_INCREMENT 
,`source`     VARCHAR(60) 
,`destination`     VARCHAR(60) 

,PRIMARY KEY (`line_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `trip`
--

CREATE TABLE IF NOT EXISTS `trip` (
`trip_id`     int(11) NOT NULL AUTO_INCREMENT 
,`Distance`     VARCHAR(60) 
,`duration`     VARCHAR(60) 
,`depature_time`     VARCHAR(60) 
, `bus`     int(11)   
,`done`     VARCHAR(60) 
,`entry_date`     Date 
,`User`     VARCHAR(60) 

,PRIMARY KEY (`trip_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `reservation`
--

CREATE TABLE IF NOT EXISTS `reservation` (
`reservation_id`     int(11) NOT NULL AUTO_INCREMENT 
, `profile`     int(11)   
, `trip`     int(11)   
,`status`     VARCHAR(60) 
,`entry_date`     Date 
,`User`     VARCHAR(60) 

,PRIMARY KEY (`reservation_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `payment`
--

CREATE TABLE IF NOT EXISTS `payment` (
`payment_id`     int(11) NOT NULL AUTO_INCREMENT 
, `amount`     int(11)   
,`profile`     VARCHAR(60) 
,`entry_date`     Date 
,`User`     VARCHAR(60) 

,PRIMARY KEY (`payment_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

