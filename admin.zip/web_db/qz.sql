 

select * from profile;

select * from bus 
join line on line.line_id=bus.line;


select * from reservation 
join trip on trip.trip_id=reservation.trip;



select * from trip 
join bus on bus.bus_id=trip.bus 
join profile on profile.profile_id = bus.driver;



select trip.trip_id,bus.plate_no,trip.depature_time from trip 
                    join bus on bus.bus_id=trip.bus 
                    join profile on profile.profile_id = bus.driver;








select *from payment
join reservation on reservation.reservation_id=payment.reservation
join profile on profile.profile_id=payment.profile


                    