<?php

require_once 'connection.php';
class updates{

 function update_account( $account_category, $date_created, $profile, $username, $password, $is_online,$account_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE account set 
account_category= ?, date_created= ?, profile= ?, username= ?, password= ?, is_online= ? WHERE account_id=?");
$stmt->execute(array($account_category, $date_created, $profile, $username, $password, $is_online ,$account_id ));

}
 function update_account_category( $name,$account_category_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE account_category set 
name= ? WHERE account_category_id=?");
$stmt->execute(array($name ,$account_category_id ));

}
 function update_profile( $dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image,$profile_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE profile set 
dob= ?, name= ?, last_name= ?, gender= ?, telephone_number= ?, email= ?, residence= ?, image= ? WHERE profile_id=?");
$stmt->execute(array($dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image ,$profile_id ));

}
 function update_bus( $no_seats, $plate_number, $driver,$bus_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE bus set 
no_seats= ?, plate_number= ?, driver= ? WHERE bus_id=?");
$stmt->execute(array($no_seats, $plate_number, $driver ,$bus_id ));

}
 function update_line( $source, $destination,$line_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE line set 
source= ?, destination= ? WHERE line_id=?");
$stmt->execute(array($source, $destination ,$line_id ));

}
 function update_trip( $Distance, $duration, $depature_time, $bus, $done, $entry_date, $User,$trip_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE trip set 
Distance= ?, duration= ?, depature_time= ?, bus= ?, done= ?, entry_date= ?, User= ? WHERE trip_id=?");
$stmt->execute(array($Distance, $duration, $depature_time, $bus, $done, $entry_date, $User ,$trip_id ));

}
 function update_reservation( $profile, $trip, $status, $entry_date, $User,$reservation_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE reservation set 
profile= ?, trip= ?, status= ?, entry_date= ?, User= ? WHERE reservation_id=?");
$stmt->execute(array($profile, $trip, $status, $entry_date, $User ,$reservation_id ));

}
 function update_payment( $amount, $profile, $entry_date, $User,$payment_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE payment set 
amount= ?, profile= ?, entry_date= ?, User= ? WHERE payment_id=?");
$stmt->execute(array($amount, $profile, $entry_date, $User ,$payment_id ));

}

}

