<?php
require_once '../web_db/connection.php';

class multi_values {

    function list_account($min) {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from account";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));
        ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> account </td>
                    <td>  </td><td>  </td><td>  </td><td>  </td><td>  </td><td>  </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['account_id']; ?>
                    </td>
                    <td class="account_category_id_cols account " title="account" >
                        <?php echo $this->_e($row['account_category']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['date_created']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['profile']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['username']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['password']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['is_online']); ?>
                    </td>


                    <td>
                        <a href="#" class="account_delete_link" style="color: #000080;" data-id_delete="account_id"  data-table="
                           <?php echo $row['account_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="account_update_link" style="color: #000080;" value="
                           <?php echo $row['account_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

        function list_account_by_category($name) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from account "
                    . " join account_category on account.account_category=account_category.account_category_id "
                    . " join profile on profile.profile_id=account.profile "
                    . " where account_category.name=:name "
                    . ""
                    . "";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":name" => $name));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> account </td>
                    <td>Name  </td>
                    <td>Last name  </td>
                    <td>Gender </td>

                    <td> Date created </td>
                    <td>Phone  </td><td>Username</td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td><div class="parts no_paddin_shade_no_Border datalist_usericon"></div>
                        <?php echo $row['account_id']; ?>
                    </td><td>
                        <?php echo $this->_e($row['name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['last_name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['gender']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['date_created']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['telephone_number']); ?>
                    </td>

                    <td>
                        <?php echo $this->_e($row['username']); ?>
                    </td>

                    <td>
                        <a href="#" class="account_delete_link" style="color: #000080;" data-id_delete="account_id"  data-table="
                           <?php echo $row['account_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="account_update_link" style="color: #000080;" value="
                           <?php echo $row['account_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_account_account_category($id) {

            $db = new dbconnection();
            $sql = "select   account.account_category from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['account_category'];
            echo $field;
        }

        function get_chosen_account_date_created($id) {

            $db = new dbconnection();
            $sql = "select   account.date_created from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['date_created'];
            echo $field;
        }

        function get_chosen_account_profile($id) {

            $db = new dbconnection();
            $sql = "select   account.profile from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['profile'];
            echo $field;
        }

        function get_chosen_account_username($id) {

            $db = new dbconnection();
            $sql = "select   account.username from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['username'];
            echo $field;
        }

        function get_chosen_account_password($id) {

            $db = new dbconnection();
            $sql = "select   account.password from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['password'];
            echo $field;
        }

        function get_chosen_account_is_online($id) {

            $db = new dbconnection();
            $sql = "select   account.is_online from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['is_online'];
            echo $field;
        }

        function All_account() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  account_id   from account";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_account() {
            $con = new dbconnection();
            $sql = "select account.account_id from account
                    order by account.account_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['account_id'];
            return $first_rec;
        }

        function get_last_account() {
            $con = new dbconnection();
            $sql = "select account.account_id from account
                    order by account.account_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['account_id'];
            return $first_rec;
        }

        function list_account_category($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from account_category";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> account_category </td>
                    <td>  </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['account_category_id']; ?>
                    </td>
                    <td class="name_id_cols account_category " title="account_category" >
                        <?php echo $this->_e($row['name']); ?>
                    </td>


                    <td>
                        <a href="#" class="account_category_delete_link" style="color: #000080;" data-id_delete="account_category_id"  data-table="
                           <?php echo $row['account_category_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="account_category_update_link" style="color: #000080;" value="
                           <?php echo $row['account_category_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_account_category_name($id) {

            $db = new dbconnection();
            $sql = "select   account_category.name from account_category where account_category_id=:account_category_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_category_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function All_account_category() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  account_category_id   from account_category";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_account_category() {
            $con = new dbconnection();
            $sql = "select account_category.account_category_id from account_category
                    order by account_category.account_category_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['account_category_id'];
            return $first_rec;
        }

        function get_last_account_category() {
            $con = new dbconnection();
            $sql = "select account_category.account_category_id from account_category
                    order by account_category.account_category_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['account_category_id'];
            return $first_rec;
        }

        function list_profile($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from profile";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> profile </td>
                    <td>  </td><td>  </td><td>  </td><td>  </td><td>  </td><td>  </td><td>  </td><td>  </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['profile_id']; ?>
                    </td>
                    <td class="dob_id_cols profile " title="profile" >
                        <?php echo $this->_e($row['dob']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['last_name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['gender']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['telephone_number']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['email']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['residence']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['image']); ?>
                    </td>


                    <td>
                        <a href="#" class="profile_delete_link" style="color: #000080;" data-id_delete="profile_id"  data-table="
                           <?php echo $row['profile_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="profile_update_link" style="color: #000080;" value="
                           <?php echo $row['profile_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_profile_dob($id) {

            $db = new dbconnection();
            $sql = "select   profile.dob from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['dob'];
            echo $field;
        }

        function get_chosen_profile_name($id) {

            $db = new dbconnection();
            $sql = "select   profile.name from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function get_chosen_profile_last_name($id) {

            $db = new dbconnection();
            $sql = "select   profile.last_name from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['last_name'];
            echo $field;
        }

        function get_chosen_profile_gender($id) {

            $db = new dbconnection();
            $sql = "select   profile.gender from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['gender'];
            echo $field;
        }

        function get_chosen_profile_telephone_number($id) {

            $db = new dbconnection();
            $sql = "select   profile.telephone_number from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['telephone_number'];
            echo $field;
        }

        function get_chosen_profile_email($id) {

            $db = new dbconnection();
            $sql = "select   profile.email from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['email'];
            echo $field;
        }

        function get_chosen_profile_residence($id) {

            $db = new dbconnection();
            $sql = "select   profile.residence from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['residence'];
            echo $field;
        }

        function get_chosen_profile_image($id) {

            $db = new dbconnection();
            $sql = "select   profile.image from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['image'];
            echo $field;
        }

        function All_profile() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  profile_id   from profile";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_profile() {
            $con = new dbconnection();
            $sql = "select profile.profile_id from profile
                    order by profile.profile_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['profile_id'];
            return $first_rec;
        }

        function get_last_profile() {
            $con = new dbconnection();
            $sql = "select profile.profile_id from profile
                    order by profile.profile_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['profile_id'];
            return $first_rec;
        }

        function list_bus($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select bus.bus_id,  bus.no_seats,  bus.plate_number,  bus.driver,  bus.line,  profile.name,  profile.last_name from bus "
                    . " join profile on profile.profile_id = bus.driver";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> bus </td>
                    <td> no_seats </td><td> Plate Number </td><td> Driver </td>
                    <?php if (isset($_SESSION['shall_delete'])) { ?>
                        <td>Delete</td><td>Update</td><?php } ?></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['bus_id']; ?>
                    </td>
                    <td class="no_seats_id_cols bus " title="bus" >
                        <?php echo $this->_e($row['no_seats']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['plate_number']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['name'] . ' ' . $row['last_name']); ?>
                    </td>
                    <?php if (isset($_SESSION['shall_delete'])) { ?>
                        <td>
                            <a href="#" class="bus_delete_link" style="color: #000080;" data-id_delete="bus_id"  data-table="
                               <?php echo $row['bus_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="bus_update_link" style="color: #000080;" value="
                               <?php echo $row['bus_id']; ?>">Update</a>
                        </td><?php } ?></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_bus_no_seats($id) {

            $db = new dbconnection();
            $sql = "select   bus.no_seats from bus where bus_id=:bus_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':bus_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['no_seats'];
            echo $field;
        }

        function get_chosen_bus_plate_number($id) {

            $db = new dbconnection();
            $sql = "select   bus.plate_number from bus where bus_id=:bus_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':bus_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['plate_number'];
            echo $field;
        }

        function get_chosen_bus_driver($id) {

            $db = new dbconnection();
            $sql = "select   bus.driver from bus where bus_id=:bus_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':bus_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['driver'];
            echo $field;
        }

        function All_bus() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  bus_id   from bus";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_bus() {
            $con = new dbconnection();
            $sql = "select bus.bus_id from bus
                    order by bus.bus_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['bus_id'];
            return $first_rec;
        }

        function get_last_bus() {
            $con = new dbconnection();
            $sql = "select bus.bus_id from bus
                    order by bus.bus_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['bus_id'];
            return $first_rec;
        }

        function list_line($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from line";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> line </td>
                    <td> Source </td>
                    <td> Destination </td>

                    <?php if ($_SESSION['cat'] == 'admin') { ?>
                        <td>Delete</td><td>Update</td>
                    <?php } ?>
                </tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['line_id']; ?>
                    </td>
                    <td class="source_id_cols line " title="line" >
                        <?php echo $this->_e($row['source']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['destination']); ?>
                    </td>

                    <?php if ($_SESSION['cat'] == 'admin') {
                        ?>
                        <td>
                            <a href="#" class="line_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['line_id']; ?>"  data-table="line">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="line_update_link" style="color: #000080;" value="
                               <?php echo $row['line_id']; ?>">Update</a>
                        </td>
                    <?php } ?>
                </tr>
                <?php
                $pages += 1;
            }
            ?></table>
        <?php
    }

//chosen individual field
    function get_chosen_line_source($id) {

        $db = new dbconnection();
        $sql = "select   line.source from line where line_id=:line_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':line_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['source'];
        echo $field;
    }

    function get_chosen_line_destination($id) {

        $db = new dbconnection();
        $sql = "select   line.destination from line where line_id=:line_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':line_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['destination'];
        echo $field;
    }

    function All_line() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  line_id   from line";
        foreach ($db->query($sql) as $row) {
            $c += 1;
        }
        return $c;
    }

    function get_first_line() {
        $con = new dbconnection();
        $sql = "select line.line_id from line
                    order by line.line_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['line_id'];
        return $first_rec;
    }

    function get_last_line() {
        $con = new dbconnection();
        $sql = "select line.line_id from line
                    order by line.line_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['line_id'];
        return $first_rec;
    }

    function list_trip($min) {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select trip.trip_id,  trip.Distance,  trip.duration,trip.price,  trip.depature_time,  trip.bus,  trip.done,  trip.entry_date,  trip.User,  bus.bus_id,  bus.no_seats,  bus.plate_number,  bus.driver,  bus.line"
                . " ,line.source, line.destination ,"
                . " bus.plate_number from trip "
                . " "
                . " join bus on bus.bus_id=trip.bus"
                . " join line on bus.line =line.line_id "
                . " ";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));
        ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> trip </td>
                    <td> Line </td>
                    <td> Bus </td>
                    <td> Distance </td>
                    <td> Duration </td>
                    <td> Price </td>
                    <td> Depature Time </td>
                    <td> Bus </td>

                    <td> Entry Date </td> <?php if (isset($_SESSION['shall_delete'])) { ?>
                        <td>Delete</td><td>Update</td>xp <?php } ?></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['trip_id']; ?>
                    </td>
                    <td>   <?php echo $row['source'] . ' - ' . $row['destination']; ?>  </td>
                    <td>   <?php echo $row['plate_number']; ?>  </td>
                    <td class="Distance_id_cols trip " title="trip" >
                        <?php echo $this->_e($row['Distance'] . ' km'); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['duration'] . ' hours'); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['price']) . ' Frw'; ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['depature_time']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['plate_number']); ?>
                    </td>

                    <td>
                        <?php echo $this->_e($row['entry_date']); ?>
                    </td>

                    <?php if (isset($_SESSION['shall_delete'])) { ?>                        <td>
                            <a href="#" class="trip_delete_link" style="color: #000080;" data-id_delete="trip_id"  data-table="
                               <?php echo $row['trip_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="trip_update_link" style="color: #000080;" value="
                               <?php echo $row['trip_id']; ?>">Update</a>
                        </td><?php } ?></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_trip_Distance($id) {

            $db = new dbconnection();
            $sql = "select   trip.Distance from trip where trip_id=:trip_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':trip_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['Distance'];
            echo $field;
        }

        function get_chosen_trip_duration($id) {

            $db = new dbconnection();
            $sql = "select   trip.duration from trip where trip_id=:trip_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':trip_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['duration'];
            echo $field;
        }

        function get_chosen_trip_depature_time($id) {

            $db = new dbconnection();
            $sql = "select   trip.depature_time from trip where trip_id=:trip_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':trip_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['depature_time'];
            echo $field;
        }

        function get_chosen_trip_bus($id) {

            $db = new dbconnection();
            $sql = "select   trip.bus from trip where trip_id=:trip_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':trip_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['bus'];
            echo $field;
        }

        function get_chosen_trip_done($id) {

            $db = new dbconnection();
            $sql = "select   trip.done from trip where trip_id=:trip_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':trip_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['done'];
            echo $field;
        }

        function get_chosen_trip_entry_date($id) {

            $db = new dbconnection();
            $sql = "select   trip.entry_date from trip where trip_id=:trip_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':trip_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['entry_date'];
            echo $field;
        }

        function get_chosen_trip_User($id) {

            $db = new dbconnection();
            $sql = "select   trip.User from trip where trip_id=:trip_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':trip_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['User'];
            echo $field;
        }

        function All_trip() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  trip_id   from trip";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_trip() {
            $con = new dbconnection();
            $sql = "select trip.trip_id from trip
                    order by trip.trip_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['trip_id'];
            return $first_rec;
        }

        function get_last_trip() {
            $con = new dbconnection();
            $sql = "select trip.trip_id from trip
                    order by trip.trip_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['trip_id'];
            return $first_rec;
        }

        function list_reservation($min) {
            try {
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $sql = "select reservation.reservation_id,  reservation.profile,  reservation.trip,  reservation.status,  reservation.entry_date,  reservation.User, reservation.seat_no,reservation.pickup, "
                        . " trip.trip_id,  trip.Distance,  trip.duration,  trip.depature_time,  trip.bus,  trip.done,  trip.entry_date,  trip.User, "
                        . " bus.bus_id,  bus.no_seats,  bus.plate_number,  bus.driver,  bus.line, "
                        . "  line.source,  line.destination, "
                        . " profile.profile_id,  profile.dob,  profile.name,  profile.last_name,  profile.gender,  profile.telephone_number,  profile.email,  profile.residence "
                        . " from reservation "
                        . " join trip on trip.trip_id=reservation.trip "
                        . " join bus on bus.bus_id=trip.bus 
                                join line on line.line_id=bus.line
                                join profile on profile.profile_id = reservation.profile";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>
                        <td> reservation </td>
                        <td> Passenger </td>
                        <?php if (isset($_SESSION['cat'])) {
                            ?><td>Phone</td><?php } ?>
                        <td> Address </td>
                        <td> Trip    </td>
                        <td> Pickup place    </td>
                        <td> Seat number </td>
                        <td> Entry Date </td> 
                        <?php
                        if ($_SESSION['cat'] == 'admin') {
                            ?><td>Option</td><?php
                        }
                        if (isset($_SESSION['shall_delete'])) {
                            ?>
                            <td>Delete</td><td>Update</td><?php } ?></tr>
                </thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['reservation_id']; ?>
                        </td>
                        <td class="profile_id_cols reservation " title="reservation" >
                            <?php echo $this->_e($row['name'] . ' ' . $row['last_name']); ?>
                        </td>
                        <?php if (isset($_SESSION['cat'])) {
                            ?>  
                            <td class="profile_id_cols reservation " title="reservation" >
                                <?php echo $this->_e($row['telephone_number']); ?>
                            </td>
                        <?php }
                        ?>
                        <td class="profile_id_cols reservation " title="reservation" >
                            <?php echo $this->_e($row['residence']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['plate_number'] . ' - ' . $row['trip'] . ' / ' . $row['source'] . ' => ' . $row['destination']); ?>
                        </td>
                        <td>
                            <?php echo $row['pickup']; ?>
                        </td>
                        <td><?php echo 'st.' . $row['seat_no']; ?></td>
                        <td>
                            <?php echo $this->_e($row['entry_date']); ?>
                        </td>
                        <?php if ($_SESSION['cat'] == 'admin') { ?>
                            <td>
                                <a href="#" class="cancel_link" data-table_id="<?php echo $row['reservation_id']; ?>"  style="color: #000080;">Cancel</a>
                            </td>
                            <?php
                        }
                        if (isset($_SESSION['shall_delete'])) {
                            ?>
                            <td>
                                <a href="#" class="reservation_delete_link" style="color: #000080;" data-id_delete="reservation_id"  data-table="
                                   <?php echo $row['reservation_id']; ?>">Delete</a>
                            </td>
                            <td>
                                <a href="#" class="reservation_update_link" style="color: #000080;" value="
                                   <?php echo $row['reservation_id']; ?>">Update</a>
                            </td><?php } ?></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            } catch (PDOException $e) {
                echo $e->getMessage();
            }
        }

//chosen individual field
        function get_chosen_reservation_profile($id) {

            $db = new dbconnection();
            $sql = "select   reservation.profile from reservation where reservation_id=:reservation_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':reservation_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['profile'];
            echo $field;
        }

        function get_chosen_reservation_trip($id) {

            $db = new dbconnection();
            $sql = "select   reservation.trip from reservation where reservation_id=:reservation_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':reservation_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['trip'];
            echo $field;
        }

        function get_chosen_reservation_status($id) {

            $db = new dbconnection();
            $sql = "select   reservation.status from reservation where reservation_id=:reservation_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':reservation_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['status'];
            echo $field;
        }

        function get_chosen_reservation_entry_date($id) {

            $db = new dbconnection();
            $sql = "select   reservation.entry_date from reservation where reservation_id=:reservation_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':reservation_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['entry_date'];
            echo $field;
        }

        function get_chosen_reservation_User($id) {

            $db = new dbconnection();
            $sql = "select   reservation.User from reservation where reservation_id=:reservation_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':reservation_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['User'];
            echo $field;
        }

        function All_reservation() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  reservation_id   from reservation";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_reservation() {
            $con = new dbconnection();
            $sql = "select reservation.reservation_id from reservation
                    order by reservation.reservation_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['reservation_id'];
            return $first_rec;
        }

        function get_last_reservation() {
            $con = new dbconnection();
            $sql = "select reservation.reservation_id from reservation
                    order by reservation.reservation_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['reservation_id'];
            return $first_rec;
        }

        function list_payment($min) {
            $database = new dbconnection();
            $db = $database->openConnection();

            $sql = "select payment.payment_id,  payment.amount, reservation.reservation_id,  reservation.profile,  reservation.trip,  reservation.status,  reservation.entry_date,  reservation.User,reservation.pickup, "
                    . " trip.trip_id,  trip.Distance,  trip.duration,  trip.depature_time,  trip.bus,  trip.done,  trip.entry_date,  trip.User, "
                    . " bus.bus_id,  bus.no_seats,  bus.plate_number,  bus.driver,  bus.line, "
                    . "  line.source,  line.destination, "
                    . " profile.profile_id,  profile.dob,  profile.name,  profile.last_name,  profile.gender,  profile.telephone_number,  profile.email,  profile.residence "
                    . " from payment "
                    . " join reservation on reservation.reservation_id=payment.reservation "
                    . "  join trip on trip.trip_id=reservation.trip "
                    . " join bus on bus.bus_id=trip.bus 
                            join line on line.line_id=bus.line
                            join profile on profile.profile_id = reservation.profile";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> payment </td>
                    <td> reservation </td>
                    <td> Amount </td><td> Profile </td>
                    <td> Entry Date </td> <?php if (isset($_SESSION['shall_delete'])) { ?>
                        <td>Delete</td><td>Update</td><?php } ?></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>  <?php echo $row['payment_id']; ?>   </td>
                    <td>
                        <?php echo $this->_e($row['name'] . ' ' . $row['last_name'] . ' ' . $row['plate_number'] . ' - ' . $row['trip'] . ' / ' . $row['source'] . ' => ' . $row['destination']); ?>
                    </td>
                    <td class="amount_id_cols payment " title="payment" >
                        <?php echo $this->_e($row['amount']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['name'] . ' ' . $row['last_name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['entry_date']); ?>
                    </td>
                    <?php if (isset($_SESSION['shall_delete'])) { ?>
                        <td>
                            <a href="#" class="payment_delete_link" style="color: #000080;" data-id_delete="payment_id"  data-table="
                               <?php echo $row['payment_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="payment_update_link" style="color: #000080;" value="
                               <?php echo $row['payment_id']; ?>">Update</a>
                        </td>
                    <?php } ?>
                </tr>
                <?php
                $pages += 1;
            }
            ?></table>
        <?php
    }

    function list_last_payment($min) {
        try {
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = " select payment.payment_id,profile.name,profile.last_name,profile.telephone_number as phone_number,  payment.amount,  payment.profile,  payment.entry_date,  payment.User,  payment.reservation from payment"
                    . " join profile on profile.profile_id= payment.profile "
                    . "   order by payment.payment_id desc limit 1";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
            <table class="dataList_table">
                <thead><tr>
                        <td> payment </td>

                        <td> Amount </td>
                        <td> Profile </td>
                        <td> Entry Date </td>
                        <?php if (isset($_SESSION['shall_delete'])) { ?>
                            <td>Delete</td><td>Update</td><?php } ?></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>  <?php echo $row['payment_id']; ?>   </td>
                        <td>
                            <?php echo $this->_e($row['name'] . ' ' . $row['last_name'] . ' '); ?>
                        </td>
                        <td class="amount_id_cols payment " title="payment" >
                            <?php echo $this->_e($row['amount']); ?>
                        </td>

                        <td>
                            <?php echo $this->_e($row['name']) . ' ' . $row['last_name']; ?>
                        </td>


                    </tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
            <?php
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    }

//chosen individual field
    function get_chosen_payment_amount($id) {

        $db = new dbconnection();
        $sql = "select   payment.amount from payment where payment_id=:payment_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':payment_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['amount'];
        echo $field;
    }

    function get_chosen_payment_profile($id) {

        $db = new dbconnection();
        $sql = "select   payment.profile from payment where payment_id=:payment_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':payment_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['profile'];
        echo $field;
    }

    function get_chosen_payment_entry_date($id) {

        $db = new dbconnection();
        $sql = "select   payment.entry_date from payment where payment_id=:payment_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':payment_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['entry_date'];
        echo $field;
    }

    function get_chosen_payment_User($id) {

        $db = new dbconnection();
        $sql = "select   payment.User from payment where payment_id=:payment_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':payment_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['User'];
        echo $field;
    }

    function All_payment() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  payment_id   from payment";
        foreach ($db->query($sql) as $row) {
            $c += 1;
        }
        return $c;
    }

    function get_first_payment() {
        $con = new dbconnection();
        $sql = "select payment.payment_id from payment
                    order by payment.payment_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['payment_id'];
        return $first_rec;
    }

    function get_profile_by_phone($phone) {
        $con = new dbconnection();
        $sql = "select profile.profile_id from profile
                        join reservation on reservation.profile=profile.profile_id
                        where profile.telephone_number=:phone";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array(":phone" => $phone));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['profile_id'];
        return $first_rec;
    }

    function get_payment_done($profile) {
        $con = new dbconnection();
        $sql = " select payment.reservation 
                 from payment 
                 join reservation on reservation.reservation_id=payment.reservation
                 join trip on trip.trip_id=reservation.trip
                 join profile on reservation.profile=profile.profile_id
                 where profile.profile_id=:profile ";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array(":profile" => $profile));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['reservation'];
        return $first_rec;
    }

    function get_last_payment() {
        $con = new dbconnection();
        $sql = "select payment.payment_id from payment
                    order by payment.payment_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['payment_id'];
        return $first_rec;
    }

    function get_account_category_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account_category.account_category_id,   account_category.name from account_category";
        ?>
        <select class="textbox cbo_account_category"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_category_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_image_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select image.image_id,   image.name from image";
        ?>
        <select class="textbox cbo_image"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['image_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_driver_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select profile.profile_id,profile.name,profile.last_name from profile";
        ?>
        <select class="textbox cbo_driver"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['profile_id'] . ">" . $row['name'] . " " . $row['last_name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_line_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select line.line_id, line.source,line.destination from line";
        ?>
        <select class="textbox cbo_line"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['line_id'] . ">" . $row['source'] . " - " . $row['destination'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_bus_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select bus.bus_id,   bus.no_seats from bus";
        ?>
        <select class="textbox cbo_bus"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['bus_id'] . "> bus " . $row['bus_id'] . " -" . $row['no_seats'] . " seats </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_trip_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select trip.trip_id,bus.plate_number,trip.depature_time, line.source,line.destination, bus.no_seats from trip 
                    join bus on bus.bus_id=trip.bus 
                    join line on line.line_id=bus.line
                    join profile on profile.profile_id = bus.driver";
        ?>
        <select class="textbox cbo_trip">
            <option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['trip_id'] . ">" . $row['plate_number'] . " (" . $row['no_seats'] . " seats) / " . $row['depature_time'] . " / " . $row['source'] . "-" . $row['destination'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_reservation_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select trip.trip_id,bus.plate_number,trip.depature_time, line.source,line.destination,reservation.reservation_id from reservation "
                . " join trip on trip.trip_id=reservation.trip "
                . " join bus on bus.bus_id=trip.bus "
                . " join line on line.line_id=bus.line ";
        ?>
        <select class="textbox cbo_reservation" name="cbo_trip"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['trip_id'] . ">" . $row['plate_number'] . " / " . $row['depature_time'] . " / " . $row['source'] . "-" . $row['destination'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_res_by_trip($trip) {
        $con = new dbconnection();
        $sql = "select reservation.reservation_id from reservation where reservation.trip=:trip";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array(":trip" => $trip));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['reservation_id'];
        return $first_rec;
    }

    function get_trip_price($trip) {
        $con = new dbconnection();
        $sql = "select trip.price from trip where trip.trip_id=:trip";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array(":trip" => $trip));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['price'];
        return $first_rec;
    }

    function get_profile_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select profile.profile_id,   profile.name ,profile.last_name from profile";
        ?>
        <select class="textbox cbo_profile"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['profile_id'] . ">" . $row['name'] . " " . $row['last_name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_reservation_report() {
        $con = new dbconnection();
        $sql = "select reservation.reservation_id,  reservation.profile,  reservation.trip,  reservation.status,  reservation.entry_date,  reservation.User, reservation.seat_no, "
                . " trip.trip_id,  trip.Distance,  trip.duration,  trip.depature_time,  trip.bus,  trip.done,  trip.entry_date,  trip.User, "
                . " bus.bus_id,  bus.no_seats,  bus.plate_number,  bus.driver,  bus.line, "
                . "  line.source,  line.destination, "
                . " profile.profile_id,profile.telephone_number,  profile.dob,  profile.name,  profile.last_name,  profile.gender,  profile.telephone_number,  profile.email,  profile.residence "
                . " from reservation "
                . " join trip on trip.trip_id=reservation.trip "
                . " join bus on bus.bus_id=trip.bus 
                            join line on line.line_id=bus.line
                            join profile on profile.profile_id = reservation.profile
                          ";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> reservation </td>
                    <td> Passenger </td>
                    <td> Trip </td>
                    <td> Seat number </td>
                    <td> Entry Date </td> 
                    <?php if (isset($_SESSION['shall_delete'])) { ?>
                        <td>Delete</td><td>Update</td><?php } ?></tr>
            </thead>

            <?php
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['reservation_id']; ?>
                    </td>
                    <td class="profile_id_cols reservation " title="reservation" >
                        <?php echo $this->_e($row['name'] . ' ' . $row['last_name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['plate_number'] . ' - ' . $row['trip'] . ' / ' . $row['source'] . ' => ' . $row['destination']); ?>
                    </td>
                    <td><?php echo 'st.' . $row['seat_no']; ?></td>
                    <td>
                        <?php echo $this->_e($row['entry_date']); ?>
                    </td>
                    <?php if (isset($_SESSION['shall_delete'])) { ?>
                        <td>
                            <a href="#" class="reservation_delete_link" style="color: #000080;" data-id_delete="reservation_id"  data-table="
                               <?php echo $row['reservation_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="reservation_update_link" style="color: #000080;" value="
                               <?php echo $row['reservation_id']; ?>">Update</a>
                        </td><?php } ?></tr>
            <?php }
            ?></table><?php
        }

        function get_reservation_by_phone($phone) {
            $con = new dbconnection();
            $sql = "select reservation.reservation_id,  reservation.profile,  reservation.trip,  reservation.status,  reservation.entry_date,  reservation.User, reservation.seat_no, "
                    . " trip.trip_id,  trip.Distance,  trip.duration,  trip.depature_time,  trip.bus,  trip.done,  trip.entry_date,  trip.User, "
                    . " bus.bus_id,  bus.no_seats,  bus.plate_number,  bus.driver,  bus.line, "
                    . "  line.source,  line.destination, "
                    . " profile.profile_id,profile.telephone_number,  profile.dob,  profile.name,  profile.last_name,  profile.gender,  profile.telephone_number,  profile.email,  profile.residence "
                    . " from reservation "
                    . " join trip on trip.trip_id=reservation.trip "
                    . " join bus on bus.bus_id=trip.bus 
                            join line on line.line_id=bus.line
                            join profile on profile.profile_id = reservation.profile
                            where profile.telephone_number=:phone";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute(array(":phone" => $phone));
            ?>
        <table>
            <thead><tr>
                    <td> reservation </td>
                    <td> Passenger </td>
                    <td> Trip </td>
                    <td> Seat number </td>
                    <td> Entry Date </td> 
                    <?php if (isset($_SESSION['shall_delete'])) { ?>
                        <td>Delete</td><td>Update</td><?php } ?></tr>
            </thead>

            <?php
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['reservation_id']; ?>
                    </td>
                    <td class="profile_id_cols reservation " title="reservation" >
                        <?php echo $this->_e($row['name'] . ' ' . $row['last_name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['plate_number'] . ' - ' . $row['trip'] . ' / ' . $row['source'] . ' => ' . $row['destination']); ?>
                    </td>
                    <td><?php echo 'st.' . $row['seat_no']; ?></td>
                    <td>
                        <?php echo $this->_e($row['entry_date']); ?>
                    </td>
                    <?php if (isset($_SESSION['shall_delete'])) { ?>
                        <td>
                            <a href="#" class="reservation_delete_link" style="color: #000080;" data-id_delete="reservation_id"  data-table="
                               <?php echo $row['reservation_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="reservation_update_link" style="color: #000080;" value="
                               <?php echo $row['reservation_id']; ?>">Update</a>
                        </td><?php } ?></tr>
            <?php }
            ?></table><?php
        }

        function get_available_seats($trip) {
            $con = new dbconnection();
            $sql = "select count(reservation.reservation_id) as all_res, min(trip.trip_id) as trip_id from reservation
                        join trip on trip.trip_id=reservation.trip
                        where trip.trip_id=:res
                        group by trip_id";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute(array(":res" => $trip));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['all_res'];
            return $first_rec;
        }

        function get_bus_seats_by_trip($trip) {
            $con = new dbconnection();
            $sql = "select bus.no_seats from trip
                    join bus on bus.bus_id=trip.bus
                    where trip.trip_id=:trip";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute(array(":trip" => $trip));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['no_seats'];
            return $first_rec;
        }
        
        function get_if_seatOnSame_date($date, $seat) {
            $con = new dbconnection();
            $sql = " select reservation_id from reservation where entry_date=:date and seat_no=:seat";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute(array(':date'=>$date, ':seat'=>$seat));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['reservation_id'];
            return $first_rec;
        }
        
        function get_all_last_payment() {
            try {
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $sql = " select * from payment "
                        . " join profile on profile.profile_id=payment.profile "
                        . " join reservation on reservation.reservation_id=payment.reservation "
                        . " join trip on trip.trip_id=reservation.trip "
                        . " join bus on bus.bus_id=trip.bus  
                            join line on line.line_id=bus.line "
                        . " order by payment.payment_id desc limit 1 ";
                $stmt = $db->prepare($sql);
                $stmt->execute();
                ?>
            <style>
                td{
                    padding: 2px;
                    font-size: 14px;
                    font-weight: bold;
                }
            </style>
            <table class="dd">
                <tr>
                    <td colspan="2"><a style="color: #000080;" target="blank" href="../prints/print_payment.php">Print</a></td>
                </tr>
                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr>   <td>Transaction number</td>  <td>  <?php echo $row['payment_id']; ?>   </td></tr>
                    <tr><td>Passenger</td>  <td> <?php echo $this->_e($row['name'] . ' ' . $row['last_name'] . ' ' . $row['plate_number'] . ' - ' . $row['trip'] . ' / ' . $row['source'] . ' => ' . $row['destination']); ?>  </td></tr>
                    <tr> <td>Amount</td>   <td class="amount_id_cols payment " title="payment" > <?php echo $this->_e($row['amount']); ?>                    </td></tr>
                    <tr><td>Names</td>    <td>  <?php echo $this->_e($row['name'] . ' ' . $row['last_name']); ?>  </td></tr>
                    <tr><td>Address</td>    <td>  <?php echo $this->_e($row['residence']); ?>  </td></tr>
                    <tr><td>Transaction date</td><td>
                            <?php echo $this->_e($row['entry_date']); ?>
                        </td></tr>
                    <tr>
                        <td>Account No.</td><td><?php echo $this->_e($row['acc_no']); ?></td>
                    </tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
            <?php
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    }

    function get_all_trip_by_date_destination($date, $destination) {
        try {
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = " select reservation.reservation_id,  reservation.profile,  reservation.trip,  reservation.status,  reservation.entry_date,  reservation.User, reservation.seat_no,reservation.pickup, "
                    . " trip.trip_id,  trip.Distance,  trip.duration,  trip.depature_time,  trip.bus,  trip.done,  trip.entry_date,  trip.User, "
                    . " bus.bus_id,  bus.no_seats,  bus.plate_number,  bus.driver,  bus.line, "
                    . "  line.source,  line.destination, "
                    . " profile.profile_id,  profile.dob,  profile.name,  profile.last_name,  profile.gender,  profile.telephone_number,  profile.email,  profile.residence, "
                    . " payment.amount "
                    . " from trip "
                    . " join bus on trip.bus=bus.bus_id "
                    . " join line on line.line_id=bus.line "
                    . " left join reservation on reservation.trip=trip.trip_id"
                    . " join profile on profile.profile_id = reservation.profile"
                    . " left join payment on payment.reservation=reservation.reservation_id "
                    . " where trip.entry_date=:date and line.destination=:dest";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":date" => $date, ":dest" => $destination));
            ?>
            <style>
                td{
                    padding: 9px;
                }
            </style>
            <table class="dd" style="width: 100%; font-size: 12px; font-weight: bold;">
                <thead style="background-color: #d4d4d4"><tr>
                        <td> reservation </td>
                        <td> Passenger </td>
                        <?php if (isset($_SESSION['cat'])) {
                            ?><td>Phone</td><?php } ?>
                        <td> Address </td>
                        <td> Trip    </td>
                        <td> Pickup place    </td>
                        <td> Seat number </td>
                        <td> Entry Date </td> 
                        <td> Amount </td> 
                        <?php
                        if ($_SESSION['cat'] == 'admin') {
                            ?><td>Option</td><?php
                        }
                        ?>

                    </tr>
                </thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    $paid = (!empty($row['amount'])) ? 'white' : 'red';
                    ?>
                    <tr> 

                        <td>
                            <?php echo $row['reservation_id']; ?>
                        </td>
                        <td class="profile_id_cols reservation " title="reservation" >
                            <?php echo $this->_e($row['name'] . ' ' . $row['last_name']); ?>
                        </td>
                        <?php if (isset($_SESSION['cat'])) {
                            ?>  
                            <td class="profile_id_cols reservation " title="reservation" >
                                <?php echo $this->_e($row['telephone_number']); ?>
                            </td>
                        <?php }
                        ?>
                        <td class="profile_id_cols reservation " title="reservation" >
                            <?php echo $this->_e($row['residence']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['plate_number'] . ' - ' . $row['trip'] . ' / ' . $row['source'] . ' => ' . $row['destination']); ?>
                        </td>
                        <td>
                            <?php echo $row['pickup']; ?>
                        </td>
                        <td><?php echo 'st.' . $row['seat_no']; ?></td>
                        <td>
                            <?php echo $this->_e($row['entry_date']); ?>
                        </td>
                        <?php if ($_SESSION['cat'] == 'admin') { ?>
                            <td>
                                <a href="#" class="cancel_link" data-table_id="<?php echo $row['reservation_id']; ?>"  style="color: #000080;">Cancel</a>
                            </td>
                            <?php
                        }
                        if (isset($_SESSION['shall_delete'])) {
                            ?>
                            <td>
                                <a href="#" class="reservation_delete_link" style="color: #000080;" data-id_delete="reservation_id"  data-table="
                                   <?php echo $row['reservation_id']; ?>">Delete</a>
                            </td>
                            <td>
                                <a href="#" class="reservation_update_link" style="color: #000080;" value="
                                   <?php echo $row['reservation_id']; ?>">Update</a>
                            </td><?php } ?>
                        <td style="background-color: <?php echo $paid ?>"><?php echo $row['amount'] ?></td>

                    </tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
            <?php
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    }

    function _e($string) {
        echo htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
    }

}
