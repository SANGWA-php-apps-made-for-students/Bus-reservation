
<div class="parts  eighty_centered with_logo " id="admin_header">       
    <div class="parts  no_paddin_shade_no_Border xxx_titles" id="with_logo">
        Bus Ticket booking and road pickup transport system
    </div>
</div>    
<div class="parts menu eighty_centered">

    <a href="../index.php">Home</a>
    <a href="new_line.php">Route</a>  
    <a href="new_bus.php">bus</a>
    <a href="new_trip.php">trip</a>
    <?php
//        if (isset($_SESSION)) {
//            if ($_SESSION['cat'] == 'admin') {
    ?>

    <?php if ($_SESSION['cat'] != 'admin') { ?>
        <a href="new_payment.php">payment</a>

    <?php }  if ($_SESSION['cat'] == 'driver') { ?>
        <a href="check_trip.php">Check</a>
        <?php
    }
//        }
    ?>

    <?php
    if ($_SESSION['cat'] == 'admin' || $_SESSION['cat']=='driver') {
        ?> <a href="new_reservation.php">Booking</a> <a href="search.php">Report</a>
        <div class = "parts two_fifty_right heit_free no_paddin_shade_no_Border">
            <a href = "../logout.php">Logout</a>
        </div>
        <?php
    }
    ?>
</div>
