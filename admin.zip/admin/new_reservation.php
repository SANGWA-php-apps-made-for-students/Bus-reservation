<?php
session_start();
require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_reservation'])) {
    if (isset($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'reservation') {
            require_once '../web_db/updates.php';
            $upd_obj = new updates();
            $reservation_id = $_SESSION['id_upd'];
            $profile = trim($_POST['txt_profile_id']);
            $trip = $_POST['txt_trip_id'];

            $status = $_POST['txt_status'];
            $entry_date = date("y-m-d");
            $User = $_SESSION['userid'];
            $upd_obj->update_reservation($profile, $trip, $status, $entry_date, $User, $reservation_id);
            unset($_SESSION['table_to_update']);
        }
    } else {
        $m = new multi_values();
        $profile = trim($_POST['txt_profile_id']);
        $trip = trim($_POST['txt_trip_id']);
        $status = 'done';
        $entry_date = filter_input(INPUT_POST, 'txt_date');
        $User = 8;
        $name = filter_input(INPUT_POST, 'txt_name');
        $last_name = filter_input(INPUT_POST, 'txt_last_name');
        $telephone_number = filter_input(INPUT_POST, 'txt_telephone');
        $seat_no = filter_input(INPUT_POST, 'txt_seat_no');
        $txt_address = filter_input(INPUT_POST, 'txt_address');
        require_once '../web_db/new_values.php';
        $obj = new new_values();
        $booked_seats = $m->get_available_seats($trip);
        $seats = $m->get_bus_seats_by_trip($trip);
        $pickup = (empty(filter_input(INPUT_POST, 'txt_pickup2'))) ? filter_input(INPUT_POST, 'txt_pickup') : filter_input(INPUT_POST, 'txt_pickup2');
        $seat_date_available = $m->get_if_seatOnSame_date($entry_date, $seat_no);

        if ($seats <= $booked_seats) {//if the seats are not over       
            ?>  <script> alert('There are no more seats avaialable  <?php echo $seats ?>');</script> <?php
        } else if ($seat_date_available > 0) {
            ?>  <script> alert('The seat is already booked, please take another');</script> <?php
        } else {
            $obj->new_profile('1990-01-01', $name, $last_name, '', $telephone_number, '', $txt_address, 0);
            $last_profl = $m->get_last_profile();
            $obj->new_reservation($last_profl, $trip, $status, $entry_date, $User, $seat_no, $pickup);
        }
    }
}
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>
            reservation</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/ui_scripts/jquery-ui.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/ui_scripts/jquery-ui.min.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/ui_scripts/jquery-ui.structure.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/ui_scripts/jquery-ui.structure.min.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/ui_scripts/jquery-ui.theme.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/ui_scripts/jquery-ui.theme.min.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
    </head>
    <body>
        <form action="new_reservation.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->
            <input type="hidden" id="txt_profile_id"   name="txt_profile_id"/>
            <input type="hidden" id="txt_trip_id"   name="txt_trip_id"/>

            <?php
            include 'admin_header.php';
            ?>

            <!--Start dialog's-->
            <div class="parts abs_full y_n_dialog off">
                <div class="parts dialog_yes_no no_paddin_shade_no_Border reverse_border">
                    <div class="parts full_center_two_h heit_free margin_free skin">
                        Do you really want to delete this record?
                    </div>
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border top_off_x margin_free">
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_xx link_cursor yes_dlg_btn" id="citizen_yes_btn">Yes</div>
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_seventy link_cursor no_btn" id="no_btn">No</div>
                    </div>
                </div>
            </div>   
            <!--End dialog-->

            <div class="parts eighty_centered no_paddin_shade_no_Border hider_box">  
                <div class="parts  no_paddin_shade_no_Border new_data_hider"> Add booking </div>
            </div> 
            <div class="parts eighty_centered off saved_dialog">
                reservation saved successfully!</div>
            <?php if (isset($_SESSION['cat'])) { ?>
                <div class="parts eighty_centered new_data_box off">
                <?php } else { ?>
                    <div class="parts eighty_centered new_data_box ">
                    <?php } ?>
                    <div class="parts eighty_centered new_data_title">Booking Registration </div>
                    <table class="new_data_table">
                        <tr><td class="new_data_tb_frst_cols">Name </td><td> <input type="text" required autocomplete="off" class="textbox" name="txt_name"  />  </td></tr>
                        <tr><td class="new_data_tb_frst_cols">Last name </td><td> <input type="text" required autocomplete="off" class="textbox" name="txt_last_name"  />  </td></tr>
                        <tr><td class="new_data_tb_frst_cols">Telephone </td><td> <input  maxlength="10"  type="text" autocomplete="off" class="textbox only_numbers" name="txt_telephone"  />  </td></tr>
                        <tr><td class="new_data_tb_frst_cols">Reservation date </td><td> <input  maxlength="10"  type="text" autocomplete="off" class="textbox only_numbers res_date" name="txt_date"  />  </td></tr>
                        <tr><td class="new_data_tb_frst_cols">Address </td><td> <input type="text" required="" autocomplete="off" class="textbox" name="txt_address"  />  </td></tr>
                        <tr><td class="new_data_tb_frst_cols">Route </td><td> <?php get_trip_combo(); ?>  </td></tr>
                        <tr><td class="new_data_tb_frst_cols">pickup location </td><td>



                                <select required="true" id="another_loc"  name="txt_pickup">
                                    <option></option>
                                    <option>12th stop</option>
                                    <option>15th stop</option>
                                    <option>Mulindi market</option>
                                    <option>Inyange industries</option>
                                    <option>Kabuga</option>
                                    <option>Masaka</option>
                                    <option>Nyagasambu</option>
                                    <option>Rwamagana</option>
                                    <option value="another_loc">Choose another location</option>
                                </select>
                                <input type="text" class="textbox off"    id="txt_pickup2"  name="txt_pickup2"   />

                            </td></tr>
                        <tr><td class="new_data_tb_frst_cols">Seat number </td><td>
                                <select required="" name="txt_seat_no" >
                                    <option></option>
                                    <option>1</option>
                                    <option>2</option>
                                    <option>3</option>
                                    <option>4</option>
                                    <option>5</option>
                                    <option>6</option>
                                    <option>7</option>
                                    <option>8</option>
                                    <option>9</option>
                                    <option>10</option>
                                    <option>11</option>
                                    <option>12</option>
                                    <option>13</option>
                                    <option>14</option>
                                    <option>15</option>
                                    <option>16</option>
                                    <option>17</option>
                                    <option>18</option>
                                    <option>19</option>
                                    <option>20</option>
                                    <option>21</option>
                                    <option>22</option>
                                    <option>23</option>
                                    <option>24</option>
                                    <option>25</option>
                                    <option>26</option>
                                    <option>27</option>
                                    <option>28</option>
                                    <option>29</option>
                                </select>
                            </td></tr>

                        <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_reservation" value="Save"/>  </td></tr>
                    </table>
                </div>
                <?php if ($_SESSION['cat'] == 'admin') { ?>
                    <div class="parts eighty_centered datalist_box" >
                        <div class="parts no_shade_noBorder xx_titles no_bg whilte_text dataList_title">Booking List</div>
                        <?php
                        $obj = new multi_values();
                        $first = $obj->get_first_reservation();
                        $obj->list_reservation($first);
                        ?>
                    </div>  <?php } ?>
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script src="../web_scripts/ui_scripts/jquery-ui.js" type="text/javascript"></script>
        <script src="../web_scripts/ui_scripts/jquery-ui.min.js" type="text/javascript"></script>

        <script>
                 $(document).ready(function () {
                     $('.res_date').datepicker({
                         dateFormat: 'yy-mm-dd',
                         minDate: new Date()

                     });

                     $('#another_loc').change(function () {
                         var location = $(this).val().trim();
                         if (location == 'another_loc') {
                             $('#txt_pickup2').show();

                         } else {
                             $('#txt_pickup2').hide();
                         }
                     });
                 });
        </script>
        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

function get_profile_combo() {
    $obj = new multi_values();
    $obj->get_profile_in_combo();
}

function get_trip_combo() {
    $obj = new multi_values();
    $obj->get_trip_in_combo();
}

function chosen_profile_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'reservation') {
            $id = $_SESSION['id_upd'];
            $profile = new multi_values();
            return $profile->get_chosen_reservation_profile($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_trip_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'reservation') {
            $id = $_SESSION['id_upd'];
            $trip = new multi_values();
            return $trip->get_chosen_reservation_trip($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_status_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'reservation') {
            $id = $_SESSION['id_upd'];
            $status = new multi_values();
            return $status->get_chosen_reservation_status($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_entry_date_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'reservation') {
            $id = $_SESSION['id_upd'];
            $entry_date = new multi_values();
            return $entry_date->get_chosen_reservation_entry_date($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_User_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'reservation') {
            $id = $_SESSION['id_upd'];
            $User = new multi_values();
            return $User->get_chosen_reservation_User($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}
