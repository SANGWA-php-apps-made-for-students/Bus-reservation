<?php
session_start();
require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>
            line</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/ui_scripts/jquery-ui.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/ui_scripts/jquery-ui.min.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/ui_scripts/jquery-ui.structure.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/ui_scripts/jquery-ui.structure.min.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/ui_scripts/jquery-ui.theme.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/ui_scripts/jquery-ui.theme.min.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
    </head>
    <body>
        <form action="redirect.php" method="get">
            <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->
            <?php include 'admin_header.php'; ?>

            <!--Start dialog's-->
            <div class="parts y_n_dialogs off" style="position: absolute; left: 0px;">
                <div class="parts dialog_yes_no no_paddin_shade_no_Border reverse_border">
                    <div class="parts full_center_two_h heit_free margin_free skin">
                        Do you really want to delete this record?
                    </div>
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border top_off_x margin_free">
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_xx link_cursor yes_dlg_btn" id="citizen_yes_btn">Yes</div>
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_seventy link_cursor no_btn" id="no_btn">No</div>
                    </div>
                </div>
            </div>   
            <!--End dialog-->


            <div class="parts eighty_centered off saved_dialog">
                line saved successfully!
            </div>
            <div class="parts eighty_centered new_data_box ">
                <div class="parts eighty_centered new_data_title">  Seat check </div>
                <table class="new_data_table">
                    <tr><td><label for="txt_source">Trip date </label></td><td> 
                            <input type="hidden" class="textbox" required="true" value="search" name="reservation_byDateDest"   />
                            <input type="text"   placeholder="Enter trip date"    name="date" required id="txt_source" class="textbox txt_date" value=""   />
                        </td></tr>
                    <tr><td><label for="txt_destination">Destination </label></td><td> 

                            <select name="dest" required id="txt_destination">
                                <option> </option>
                                <option>Rwamagana</option>
                                <option>Kayonza</option>
                                <option>Kiramuruzi</option>
                                <option>Kabarore</option>
                                <option>Karagnazi</option>
                                <option>Matimba</option>
                                <option>Kagitumba</option>
                            </select>
                        </td></tr>
                    <tr><td colspan="2">
                            <input type="submit" class="confirm_buttons" style="width: 140px;" name="send_line" value="Check"/> 
                            <?php if (isset($_SESSION['table_to_update'])) { ?>
                                <input type="submit" class="confirm_buttons cancel_btn push_right" name="cancel" value="Cancel"/>
                            <?php } ?>
                        </td></tr>

                </table>
            </div>

            <div class="parts eighty_centered datalist_box" >
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text dataList_title">Passengers List</div>
                <?php
                $obj = new multi_values();
                if (isset($_SESSION['res_destination'])) {
                    $obj->get_all_trip_by_date_destination($_SESSION['res_date'], $_SESSION['res_destination']);
                }
                ?>
            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script src="../web_scripts/ui_scripts/jquery-ui.js" type="text/javascript"></script>
        <script src="../web_scripts/ui_scripts/jquery-ui.min.js" type="text/javascript"></script>


        <script>
            $(document).ready(function () {
                $('.txt_date').datepicker({
                    dateFormat: 'yy-mm-dd'

                });
            });
        </script>
        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
