<?php
    session_start();
    if (isset($_SESSION)) {


        if ($_SESSION['cat'] == 'admin') {
            
        } else {
            $_SESSION['login_token'] = $_SESSION['cat'] = 'users';
        }
    }
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Reservation</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/> 
        <meta name="viewport" content="width=device-width, initial scale=1.0"/> 
        <style>
            #slider a{
                display: block;
                line-height: 3em;
            }
        </style>
    </head>
    <body>
        <?php    include './admin_header.php';  ?>
        <div class="parts eighty_centered">
            <table class="full_center_two_h heit_free">

                <tr>
                    <td>Enter phone</td>
                    <td><input type="text" class="textbox" id="txt_phone" autocomplete="off" name="txt_name"  /></td>
                </tr>
                <tr>
                    <td></td>
                    <td>
                        <input type="button" class="confirm_buttons" value="search" id="btn_search_report" />
                    </td>
                </tr>
                <tr>
                    <td colspan="2">
                        <div style=" height: 300px;" class="parts full_center_two_h heit_free x_height_4x" id="res_box">
                            <?php
                            require_once '../web_db/multi_values.php';
                            $obj= new multi_values();
                            $obj->get_reservation_report();  ?>
                        </div>
                    </td>
                </tr>
            </table>
        </div>


        <div id="fb-root"></div>
        <script>(function (d, s, id) {
                var js, fjs = d.getElementsByTagName(s)[0];
                if (d.getElementById(id))
                    return;
                js = d.createElement(s);
                js.id = id;
                js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.10";
                fjs.parentNode.insertBefore(js, fjs);
            }(document, 'script', 'facebook-jssdk'));</script>        
        <div class="parts eighty_centered footer">
            Copyrights <?php echo date("Y"); ?>
            <div class="fb-share-button" data-href="https://www.codeguru-pro.net" data-layout="button_count" data-size="small" data-mobile-iframe="true"><a class="fb-xfbml-parse-ignore" target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fwww.codeguru-pro.net%2Ftests%2Findex.php&amp;src=sdkpreparse">Share</a></div>   
        </div>  
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script>
            $(document).ready(function () {
                var res = '';
                try {
                    $('#btn_search_report').click(function () {
                        var reservation_by_phone = $('#txt_phone').val();

                        $.post('handler.php', {reservation_by_phone: reservation_by_phone}, function (data) {
                            res = data;

                        }).complete(function () {
                            $('#res_box').html(res);
                        });
                    });
                } catch (err) {
                    alert(err);
                }
            });
        </script>
    </body>
</html>
