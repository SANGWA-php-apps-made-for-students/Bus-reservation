<?php
session_start();
?><!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Admin dashboard</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <?php
        require_once './admin_header.php'; 
        ?>
        <div class="parts eighty_centered manager_pane off">
            <div class="parts no_paddin_shade_no_Border full_center_two_h heit_free">
                <h1>
                    WELCOME TO STELLA EXPRESS LTD  (<?php echo $_SESSION['cat'] ?>)
                </h1>
            </div>
            <br/>
             <div class="parts no_paddin_shade_no_Border full_center_two_h heit_free">
            <p>
                Choose a menu from top bar to continue
            </p></div>
        </div>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script>
            $('.manager_pane').slideDown(600);
        </script>

    </body>
</html>
