<?php
    session_start();
    require_once '../web_db/multi_values.php';
    if (!isset($_SESSION)) {
        session_start();
    }if (!isset($_SESSION['login_token'])) {
        header('location:../index.php');
    }
    if (isset($_POST['send_bus'])) {
        if (isset($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'bus') {
                require_once '../web_db/updates.php';
                $upd_obj = new updates();
                $bus_id = $_SESSION['id_upd'];
                $no_seats = $_POST['txt_no_seats'];
                $plate_number = $_POST['txt_plate_number'];
                $driver = $_POST['txt_driver_id'];
                $line = $_POST['txt_line_id'];
                $upd_obj->update_bus($no_seats, $plate_number, $driver, $line, $bus_id);
                unset($_SESSION['table_to_update']);
            }
        } else {
            $no_seats = $_POST['txt_no_seats'];
            $plate_number = $_POST['txt_plate_number'];
            $driver = trim($_POST['txt_driver_id']);
            $line = trim($_POST['txt_line_id']);
            require_once '../web_db/new_values.php';
            $obj = new new_values();
            $obj->new_bus($no_seats, $plate_number, $driver, $line);
        }
    }
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>
            bus</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
    </head>
    <body>
        <form action="new_bus.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->
            <input type="hidden" id="txt_driver_id"   name="txt_driver_id"/>
            <input type="hidden" id="txt_line_id"   name="txt_line_id"/>
            <?php
                include 'admin_header.php';
            ?>

            <!--Start dialog's-->
            <div class="parts abs_full y_n_dialog off">
                <div class="parts dialog_yes_no no_paddin_shade_no_Border reverse_border">
                    <div class="parts full_center_two_h heit_free margin_free skin">
                        Do you really want to delete this record?
                    </div>
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border top_off_x margin_free">
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_xx link_cursor yes_dlg_btn" id="citizen_yes_btn">Yes</div>
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_seventy link_cursor no_btn" id="no_btn">No</div>
                    </div>
                </div>
            </div>   
            <!--End dialog-->
            <?php if ($_SESSION['cat'] == 'admin') { ?>
                    <div class="parts eighty_centered no_paddin_shade_no_Border hider_box">  
                        <div class="parts  no_paddin_shade_no_Border new_data_hider"> Add bus </div>
                    <?php } ?>
            </div>
            <div class="parts eighty_centered off saved_dialog">
                bus saved successfully!
            </div>
            <div class="parts eighty_centered new_data_box off">
                <div class="parts eighty_centered new_data_title">  bus Registration </div>
                <table class="new_data_table">
                    <tr><td><label for="txt_no_seats">no_seats </label></td><td> <input type="text"     name="txt_no_seats" required id="txt_no_seats" class="textbox" value="<?php echo trim(chosen_no_seats_upd()); ?>"   />  </td></tr>
                    <tr><td><label for="txt_plate_number">Plate Number </label></td><td> <input type="text"     name="txt_plate_number" required id="txt_plate_number" class="textbox" value="<?php echo trim(chosen_plate_number_upd()); ?>"   />  </td></tr>
                    <tr><td class="new_data_tb_frst_cols">Driver </td><td> <?php get_driver_combo(); ?>  </td></tr> 
                    <tr><td class="new_data_tb_frst_cols">Route </td><td> <?php get_line_combo(); ?>  </td></tr>
                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_bus" value="Save"/>  </td></tr>
                </table>
            </div>

            <div class="parts eighty_centered datalist_box" >
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text dataList_title">bus List</div>
                <?php
                    $obj = new multi_values();
                    $first = $obj->get_first_bus();
                    $obj->list_bus($first);
                ?>
            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

    function get_line_combo() {
        $obj = new multi_values();
        $obj->get_line_combo();
    }

    function get_driver_combo() {
        $obj = new multi_values();
        $obj->get_driver_in_combo();
    }

    function chosen_no_seats_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'bus') {
                $id = $_SESSION['id_upd'];
                $no_seats = new multi_values();
                return $no_seats->get_chosen_bus_no_seats($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_plate_number_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'bus') {
                $id = $_SESSION['id_upd'];
                $plate_number = new multi_values();
                return $plate_number->get_chosen_bus_plate_number($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_driver_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'bus') {
                $id = $_SESSION['id_upd'];
                $driver = new multi_values();
                return $driver->get_chosen_bus_driver($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_line_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'bus') {
                $id = $_SESSION['id_upd'];
                $line = new multi_values();
                return $line->get_chosen_bus_line($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }
    