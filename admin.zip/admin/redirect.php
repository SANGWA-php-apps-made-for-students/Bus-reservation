<?php

session_start();
if (isset($_SESSION['table_to_update'])) {
    header('location:new_' . $_SESSION['table_to_update'] . '.php');
}
if (isset($_SESSION['cancel_res'])) {
    header('location:new_' . $_SESSION['cancel_res'] . '.php');
}

if (isset($_GET['reservation_byDateDest'])) {
    
    $_SESSION['res_date']=$_GET['date'];
    $_SESSION['res_destination']=$_GET['dest'];
    header('location: check_trip.php');
}
 