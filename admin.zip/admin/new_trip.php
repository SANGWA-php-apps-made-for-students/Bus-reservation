<?php
    session_start();
    require_once '../web_db/multi_values.php';
    if (!isset($_SESSION)) {
        session_start();
    }if (!isset($_SESSION['login_token'])) {
        header('location:../index.php');
    }
    if (isset($_POST['send_trip'])) {
        if (isset($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'trip') {
                require_once '../web_db/updates.php';
                $upd_obj = new updates();
                $trip_id = $_SESSION['id_upd'];
                $Distance = $_POST['txt_Distance'];
                $duration = $_POST['txt_duration'];
                $depature_time = $_POST['txt_depature_time'];
                $bus = $_POST['txt_bus_id'];
                $done = $_POST['txt_done'];
                $entry_date = date("y-m-d");

                $User = $_SESSION['userid'];

                $upd_obj->update_trip($Distance, $duration, $depature_time, $bus, $done, $entry_date, $User, $trip_id);
                unset($_SESSION['table_to_update']);
            }
        } else {
            $Distance = $_POST['txt_Distance'];
            $duration = $_POST['txt_duration'];
            $depature_time = $_POST['txt_depature_time'];
            $bus = trim($_POST['txt_bus_id']);
            $done = 'no';
            $entry_date = date("y-m-d");
            $User = 8;
            $price = filter_input(INPUT_POST, 'txt_price');

            require_once '../web_db/new_values.php';
            $obj = new new_values();
            $obj->new_trip($Distance, $duration, $depature_time, $bus, $done, $entry_date, $User, $price);
        }
    }
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>
            trip</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
    </head>
    <body>
        <form action="new_trip.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->
            <input type="hidden" id="txt_bus_id"   name="txt_bus_id"/>
            <?php
                include 'admin_header.php';
            ?>

            <!--Start dialog's-->
            <div class="parts abs_full y_n_dialog off">
                <div class="parts dialog_yes_no no_paddin_shade_no_Border reverse_border">
                    <div class="parts full_center_two_h heit_free margin_free skin">
                        Do you really want to delete this record?
                    </div>
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border top_off_x margin_free">
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_xx link_cursor yes_dlg_btn" id="citizen_yes_btn">Yes</div>
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_seventy link_cursor no_btn" id="no_btn">No</div>
                    </div>
                </div>
            </div>   
            <!--End dialog-->
            <?php if ($_SESSION['cat'] == 'admin') { ?>
                    <div class="parts eighty_centered no_paddin_shade_no_Border hider_box">  
                        <div class="parts  no_paddin_shade_no_Border new_data_hider"> Add trip </div>
                    </div>  <?php } ?>
            <div class="parts eighty_centered off saved_dialog">
                trip saved successfully!</div>
            <div class="parts eighty_centered new_data_box off">
                <div class="parts eighty_centered new_data_title">  trip Registration </div>
                <table class="new_data_table">
                    <tr><td><label for="txt_Distance">Distance </label></td><td> <input type="text"     name="txt_Distance" required id="txt_Distance" class="textbox" value="<?php echo trim(chosen_Distance_upd()); ?>"   />  </td></tr>
                    <tr><td><label for="txt_duration">Duration </label></td><td> <input type="text"     name="txt_duration" required id="txt_duration" class="textbox" value="<?php echo trim(chosen_duration_upd()); ?>"   />  </td></tr>
                    <tr><td><label for="txt_depature_time">Depature Time </label></td><td> 
                        
                            <select name="txt_depature_time" required>
                                <option> </option>
                                <option>8h:00</option>
                                <option>8h:30</option>
                                <option>9h:00</option>
                                <option>9h:30</option>
                                <option>10h:00</option>
                                <option>10h:30</option>
                                <option>11h:00</option>
                                <option>11h:30</option>
                                <option>12h:00</option>
                                <option>12h:30</option>
                                <option>13h:00</option>
                                <option>13h:30</option>
                                <option>14h:30</option>
                                <option>15h:00</option>
                                <option>15h:30</option>
                                <option>16h:00</option>
                                <option>16h:30</option>
                                <option>17h:00</option>
                                <option>17h:30</option>
                                <option>18h:00</option>
                                <option>18h:30</option>
                                <option>19h:00</option>
                                <option>19h:30</option>
                                <option>20h:00</option>
                                <option>20h:30</option>
                                
                            </select>
                        </td></tr>
                    <tr><td class="new_data_tb_frst_cols">Bus </td><td> <?php get_bus_combo(); ?>  </td></tr>
                    <tr><td class="new_data_tb_frst_cols">Amount </td><td> <input type="text" class="textbox" name="txt_price"  />  </td></tr>

                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_trip" value="Save"/>  </td></tr>
                </table>
            </div>

            <div class="parts eighty_centered datalist_box" >
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text dataList_title">trip List</div>
                <?php
                    $obj = new multi_values();
                    $first = $obj->get_first_trip();
                    $obj->list_trip($first);
                ?>
            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

    function get_bus_combo() {
        $obj = new multi_values();
        $obj->get_bus_in_combo();
    }

    function chosen_Distance_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'trip') {
                $id = $_SESSION['id_upd'];
                $Distance = new multi_values();
                return $Distance->get_chosen_trip_Distance($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_duration_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'trip') {
                $id = $_SESSION['id_upd'];
                $duration = new multi_values();
                return $duration->get_chosen_trip_duration($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_depature_time_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'trip') {
                $id = $_SESSION['id_upd'];
                $depature_time = new multi_values();
                return $depature_time->get_chosen_trip_depature_time($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_bus_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'trip') {
                $id = $_SESSION['id_upd'];
                $bus = new multi_values();
                return $bus->get_chosen_trip_bus($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_done_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'trip') {
                $id = $_SESSION['id_upd'];
                $done = new multi_values();
                return $done->get_chosen_trip_done($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_entry_date_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'trip') {
                $id = $_SESSION['id_upd'];
                $entry_date = new multi_values();
                return $entry_date->get_chosen_trip_entry_date($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_User_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'trip') {
                $id = $_SESSION['id_upd'];
                $User = new multi_values();
                return $User->get_chosen_trip_User($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }
    