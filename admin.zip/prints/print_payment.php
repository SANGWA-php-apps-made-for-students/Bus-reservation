<?php

require_once 'Fpdf/fpdf.php';
require_once '../web_db/connection.php';

class PDF extends FPDF {

// Load data
    function LoadData() {
        // Read file lines

        $database = new dbconnection();
        $db = $database->openconnection();
        $sql = " select * from payment "
                . " join profile on profile.profile_id=payment.profile"
                . " join reservation on reservation.reservation_id=payment.reservation "
                . " join trip on trip.trip_id=reservation.trip "
                . " join bus on bus.bus_id=trip.bus 
                                join line on line.line_id=bus.line"
                . " order by payment.payment_id desc limit 1";
        // <editor-fold defaultstate="collapsed" desc="----text Above (header = company addresses) ------">
        $this->Cell(120, 7, 'BUS TICKET BOOOKING AND ROAD PICK UP', 0, 0, 'L');
        $this->Cell(60, 7, 'DISTRICT: KICUKIRO', 0, 0, 'L');
        $this->Ln();
        $this->Cell(120, 7, 'RWANDA ', 0, 0, 'E');
        $this->Cell(60, 7, 'TELEPHONE: . ', 0, 0, 'L');
        $this->Ln();
        $this->Ln();
        $this->Ln();
        $this->Ln();
        $this->SetFont("Arial", 'B', 14);
        $this->Cell(50, 7, 'PAYMENT RECEIPT ', 0, 0, 'C');


        $this->Ln();
        $this->SetFont("Arial", '', 14);
// </editor-fold>


        $this->Ln();
        foreach ($db->query($sql) as $row) {
            $this->cell(10, 7, "ID:", 0, 0, 'L');
            $this->cell(30, 7, $row['payment_id'], 0, 0, 'L');
            $this->Ln();
            $this->cell(30, 7, "Passenger:", 0, 0, 'L');
            $this->cell(30, 7, $row['name'] . ' ' . $row['last_name'], 0, 0, 'L');
            $this->Ln();
            $this->cell(30, 7, "Amount:", 0, 0, 'L');
            $this->cell(30, 7, $row['amount'], 0, 0, 'L');
            $this->Ln();
            $this->cell(40, 7, "Transaction date:", 0, 0, 'L');
            $this->cell(30, 7, $row['entry_date'], 0, 0, 'L');
            $this->Ln();
            $this->cell(40, 7, "Address:", 0, 0, 'L');
            $this->cell(30, 7, $row['residence'], 0, 0, 'L');
            $this->Ln();
            $this->cell(40, 7, "Account No:", 0, 0, 'L');
            $this->cell(30, 7, $row['acc_no'], 0, 0, 'L');


            $this->Ln();
        }
    }

}

$pdf = new PDF('P', 'mm', array(100, 150));
$pdf->SetFont('Arial', '', 11);
$pdf->AddPage();
$pdf->LoadData();
$pdf->Output();
