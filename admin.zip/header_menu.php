<div class="parts  eighty_centered " style="background-color: #c7f7fc;
     border:2px solid  #2db8c5; 
     box-shadow: none;" id="with_logo">        
    <div class="parts  no_paddin_shade_no_Border xxx_titles" >
        Bus Ticket booking and road pickup transport system
    </div>
</div>   
<div class="parts menu eighty_centered">
    <a href="index.php">Home</a>
    <?php
    
    
    ?>
   
    <!--<a href="admin/search.php">Search</a>-->
    <a href="admin/new_line.php">Route</a>
    <a href="admin/new_trip.php">trip</a>
    <a href="admin/new_reservation.php">Booking</a>
    <a href="admin/new_payment.php">payment</a>
    <div class="parts two_fifty_right heit_free no_paddin_shade_no_Border">
        <a href="login.php">Login</a>

    </div>
</div>
