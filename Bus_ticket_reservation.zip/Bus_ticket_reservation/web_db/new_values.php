<?php 
class new_values{

 function new_account(  $account_category, $date_created, $profile, $username, $password, $is_online){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into account values(:account_id, :account_category,  :date_created,  :profile,  :username,  :password,  :is_online)");$stm->execute(array(':account_id'=>0,':account_category'=>$account_category, ':date_created'=>$date_created, ':profile'=>$profile, ':username'=>$username, ':password'=>$password, ':is_online'=>$is_online
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_account_category(  $name){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into account_category values(:account_category_id, :name)");$stm->execute(array(':account_category_id'=>0,':name'=>$name
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_profile(  $dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into profile values(:profile_id, :dob,  :name,  :last_name,  :gender,  :telephone_number,  :email,  :residence,  :image)");$stm->execute(array(':profile_id'=>0,':dob'=>$dob, ':name'=>$name, ':last_name'=>$last_name, ':gender'=>$gender, ':telephone_number'=>$telephone_number, ':email'=>$email, ':residence'=>$residence, ':image'=>$image
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_bus(  $no_seats, $plate_number, $driver, $line){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into bus values(:bus_id, :no_seats,  :plate_number,  :driver,  :line)");$stm->execute(array(':bus_id'=>0,':no_seats'=>$no_seats, ':plate_number'=>$plate_number, ':driver'=>$driver, ':line'=>$line
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_line(  $source, $destination){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into line values(:line_id, :source,  :destination)");$stm->execute(array(':line_id'=>0,':source'=>$source, ':destination'=>$destination
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_trip(  $Distance, $duration, $depature_time, $bus, $done, $entry_date, $User){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into trip values(:trip_id, :Distance,  :duration,  :depature_time,  :bus,  :done,  :entry_date,  :User)");$stm->execute(array(':trip_id'=>0,':Distance'=>$Distance, ':duration'=>$duration, ':depature_time'=>$depature_time, ':bus'=>$bus, ':done'=>$done, ':entry_date'=>$entry_date, ':User'=>$User
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_reservation(  $profile, $trip, $status, $entry_date, $User){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into reservation values(:reservation_id, :profile,  :trip,  :status,  :entry_date,  :User)");$stm->execute(array(':reservation_id'=>0,':profile'=>$profile, ':trip'=>$trip, ':status'=>$status, ':entry_date'=>$entry_date, ':User'=>$User
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_payment(  $amount, $profile, $entry_date, $User, $reservation){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into payment values(:payment_id, :amount,  :profile,  :entry_date,  :User,  :reservation)");$stm->execute(array(':payment_id'=>0,':amount'=>$amount, ':profile'=>$profile, ':entry_date'=>$entry_date, ':User'=>$User, ':reservation'=>$reservation
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

}

 } 
